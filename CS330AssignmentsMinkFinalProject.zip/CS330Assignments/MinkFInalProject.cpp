#include <iostream>// cout, cerr
#include <cstdlib>// EXIT_FAILURE
#include <GL/glew.h>// GLEW library
#include <GLFW/glfw3.h>// GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>// Image loading Utility functions
#include <GLAD/glad.h>

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <shader.h>
#include <shader.hpp>


#include <camera.h> // Camera class

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
	const char* const WINDOW_TITLE = "3D Scene"; // Macro for window title
	// Variables for window width and height
	const int WINDOW_WIDTH = 800;
	const int WINDOW_HEIGHT = 600;

	// Stores the GL data relative to a given mesh
	struct GLMesh
	{
		GLuint VAO;// vertex array object
		GLuint VBO;// vertex buffer object
		GLuint nVertices;// Number of indices of the mesh
	};

	// Main GLFW window
	GLFWwindow* gWindow = nullptr;
	// Triangle mesh data
	GLMesh gMesh;
	// Texture
	GLuint gTextureId;
	glm::vec2 gUVScale(5.0f, 5.0f);
	GLint gTexWrapMode = GL_REPEAT;

	// Shader programs
	GLuint gPyramidProgramId;
	GLuint gLampProgramId;

	// camera
	Camera gCamera(glm::vec3(0.0f, 0.0f, 7.0f));
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// timing
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// Subject position and scale
	glm::vec3 gPyramidPosition(0.0f, 0.0f, 0.0f);
	glm::vec3 gPyramidScale(2.0f);

	// Pyramid and light color
	glm::vec3 gObjectColor(1.f, 0.2f, 0.0f);
	glm::vec3 gLightColor(1.0f, 1.0f, 1.0f);

	// Light position and scale
	glm::vec3 gLightPosition(1.5f, 7.5f, 4.0f);
	glm::vec3 gLightScale(0.3f);
}


bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMesh(GLMesh& mesh); void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);

/* Pyramid Vertex Shader Source Code*/
const GLchar* pyramidVertexShaderSource = GLSL(440, layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f); // Transformsvertices into clip coordinates

	vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment /pixel position in world space only (exclude view and projection)
	vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectorsin world space only and exclude normal translation properties
	vertexTextureCoordinate = textureCoordinate;
}
);

/* Pyramid Fragment Shader Source Code*/
const GLchar* pyramidFragmentShaderSource = GLSL(440, in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;
out vec4 fragmentColor; // For outgoing pyramid color to the GPU


// Uniform / Global variables for object color, light color, light position, andcamera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
	/*Phong lighting model calculations to generate ambient, diffuse, and specularcomponents*/

	
	float ambientStrength = 1.0f; // Set ambient or global lighting strength
	vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

	
	vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
	vec3 lightDirection = normalize(lightPos - vertexFragmentPos);  
	float impact = max(dot(norm, lightDirection), 0.0);
	vec3 diffuse = impact * lightColor; // Generate diffuse light color

	
	float specularIntensity = 0.8f; // Set specular light strength
	float highlightSize = 8.0f; // Set specular highlight size
	vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
	vec3 reflectDir = reflect(-lightDirection, norm); // Calculate reflection vector
	
	float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
	vec3 specular = specularIntensity * specularComponent * lightColor;

	
	vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

	// Calculate phong result
	vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;
	fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

/* Lamp Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440, layout(location = 0) in vec3 position;

//Uniform / Global variables for the transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);

/* Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440, out vec4 fragmentColor; 
void main()
{
	fragmentColor = vec4(1.0f); 
}
);


void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
	for (int j = 0; j < height / 2; ++j)
	{
		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;
		for (int i = width * channels; i > 0; --i)
		{
			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}

int main(int argc, char* argv[])
{
	if (!UInitialize(argc, argv, &gWindow))
		return EXIT_FAILURE;

	// Create the mesh
	UCreateMesh(gMesh); 
	// Create the shader programs
	if (!UCreateShaderProgram(pyramidVertexShaderSource, pyramidFragmentShaderSource, gPyramidProgramId))
		return EXIT_FAILURE;

	if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
		return EXIT_FAILURE;

	// Load texture
	const char* texFilename = "resources/textures/Tropical3.jpg";
	if (!UCreateTexture(texFilename, gTextureId))
	{
		cout << "Failed to load texture " << texFilename << endl;
		return EXIT_FAILURE;
	}

	glUseProgram(gPyramidProgramId);

	glUniform1i(glGetUniformLocation(gPyramidProgramId, "uTexture"), 0);

	// Sets the background color of the window to black
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	// render loop
	while (!glfwWindowShouldClose(gWindow))
	{
		
		float currentFrame = glfwGetTime();
		gDeltaTime = currentFrame - gLastFrame;
		gLastFrame = currentFrame;

		
		UProcessInput(gWindow);

		
		URender();

		glfwPollEvents();
	}

	// Release mesh data, texture, and shader programs
	UDestroyMesh(gMesh);
	UDestroyTexture(gTextureId);
	UDestroyShaderProgram(gPyramidProgramId);
	UDestroyShaderProgram(gLampProgramId);
	exit(EXIT_SUCCESS); // Terminates the program successfully
}

// Initialize GLFW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
	// GLFW: initialize and configure
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// GLFW: window creation
	* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
	if (*window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return false;
	}

	glfwMakeContextCurrent(*window);
	glfwSetFramebufferSizeCallback(*window, UResizeWindow);
	glfwSetCursorPosCallback(*window, UMousePositionCallback);
	glfwSetScrollCallback(*window, UMouseScrollCallback);
	glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

	// tell GLFW to capture our mouse
	glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	return true;
}

// process all input
void UProcessInput(GLFWwindow* window)
{
	static const float cameraSpeed = 2.5f;

	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		gCamera.ProcessKeyboard(LEFT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		gCamera.ProcessKeyboard(DOWN, gDeltaTime);
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		gCamera.ProcessKeyboard(UP, gDeltaTime);

	if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS && gTexWrapMode != GL_REPEAT)
	{
		glBindTexture(GL_TEXTURE_2D, gTextureId);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glBindTexture(GL_TEXTURE_2D, 0);

		gTexWrapMode = GL_REPEAT;
	}

	else if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS && gTexWrapMode != GL_MIRRORED_REPEAT)
	{
		glBindTexture(GL_TEXTURE_2D, gTextureId);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
		glBindTexture(GL_TEXTURE_2D, 0);

		gTexWrapMode = GL_MIRRORED_REPEAT;
	}

	else if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS && gTexWrapMode != GL_CLAMP_TO_EDGE)
	{
		glBindTexture(GL_TEXTURE_2D, gTextureId);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glBindTexture(GL_TEXTURE_2D, 0);

		gTexWrapMode = GL_CLAMP_TO_EDGE;
	}

	else if (glfwGetKey(window, GLFW_KEY_4) == GLFW_PRESS && gTexWrapMode != GL_CLAMP_TO_BORDER)
	{
		float color[] = { 1.0f, 0.0f, 1.0f, 1.0f };
		glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color);

		glBindTexture(GL_TEXTURE_2D, gTextureId);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
		glBindTexture(GL_TEXTURE_2D, 0);
		gTexWrapMode = GL_CLAMP_TO_BORDER;
	}

	if (glfwGetKey(window, GLFW_KEY_RIGHT_BRACKET) == GLFW_PRESS)
	{
		gUVScale += 0.1f;
	}

	else if (glfwGetKey(window, GLFW_KEY_LEFT_BRACKET) == GLFW_PRESS)
	{
		gUVScale -= 0.1f;
	}
}


void UResizeWindow(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
	if (gFirstMouse)
	{
		gLastX = xpos;
		gLastY = ypos;
		gFirstMouse = false;
	}

	float xoffset = xpos - gLastX;
	float yoffset = gLastY - ypos;

	
	gLastX = xpos;
	gLastY = ypos;

	gCamera.ProcessMouseMovement(xoffset, yoffset);
}


void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
	gCamera.ProcessMouseScroll(yoffset);
}

void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
	switch (button)
	{
	case GLFW_MOUSE_BUTTON_LEFT:
	{
		if (action == GLFW_PRESS)
			cout << "Left mouse button pressed" << endl;
		else
			cout << "Left mouse button released" << endl;
	}
	break;

	case GLFW_MOUSE_BUTTON_MIDDLE:
	{
		if (action == GLFW_PRESS)
			cout << "Middle mouse button pressed" << endl;
		else
			cout << "Middle mouse button released" << endl;
	}
	break;

	case GLFW_MOUSE_BUTTON_RIGHT:
	{
		if (action == GLFW_PRESS)
			cout << "Right mouse button pressed" << endl;
		else
			cout << "Right mouse button released" << endl;
	}
	break;

	default:
		cout << "Unhandled mouse button event" << endl;
		break;
	}
}

// Functioned called to render a frame
void URender()
{
	// Enable z-depth
	glEnable(GL_DEPTH_TEST);

	// Clear the frame and z buffers
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Activate the cube VAO 
	glBindVertexArray(gMesh.VAO);

	// Set the shader to be used
	glUseProgram(gPyramidProgramId);

	// Model matrix: transformations are applied right-to-left order
	glm::mat4 model = glm::translate(gPyramidPosition) * glm::scale(gPyramidScale);

	// camera/view transformation
	glm::mat4 view = gCamera.GetViewMatrix();

	// Creates a perspective projection
	glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

	// Retrieves and passes transform matrices to the Shader program
	GLint modelLoc = glGetUniformLocation(gPyramidProgramId, "model");
	GLint viewLoc = glGetUniformLocation(gPyramidProgramId, "view");
	GLint projLoc = glGetUniformLocation(gPyramidProgramId, "projection");

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	// Reference matrix uniforms from the Pyramid Shader program 
	GLint objectColorLoc = glGetUniformLocation(gPyramidProgramId, "objectColor");
	GLint lightColorLoc = glGetUniformLocation(gPyramidProgramId, "lightColor");
	GLint lightPositionLoc = glGetUniformLocation(gPyramidProgramId, "lightPos");
	GLint viewPositionLoc = glGetUniformLocation(gPyramidProgramId, "viewPosition");

	// Pass color, light, and camera data to the Pyramid Shader program's corresponding uniforms
	glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
	glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
	glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
	const glm::vec3 cameraPosition = gCamera.Position;
	glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

	GLint UVScaleLoc = glGetUniformLocation(gPyramidProgramId, "uvScale");
	glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

	// bind textures on corresponding texture units
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTextureId);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);

	// LAMP: draw lamp
	glUseProgram(gLampProgramId);

	//Transform the smaller pyramid used as a visual que for the light source
	model = glm::translate(gLightPosition) * glm::scale(gLightScale);

	// Reference matrix uniforms from the Lamp Shader program
	modelLoc = glGetUniformLocation(gLampProgramId, "model");
	viewLoc = glGetUniformLocation(gLampProgramId, "view");
	projLoc = glGetUniformLocation(gLampProgramId, "projection");

	// Pass matrix data to the Lamp Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
	glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices);

	// Deactivate the Vertex Array Object and shader program
	glBindVertexArray(0);
	glUseProgram(0);

	// glfw: swap buffers and poll IO events
	glfwSwapBuffers(gWindow);
}

// Implements the UCreateMesh function

void UCreateMesh(GLMesh& mesh)
{
	// Position and Color data
	GLfloat verts[] =
	{
		//Positions			//Normals
		// ------------------------------------------------------
		//Front Left Face		//Negative Z Normal		Texture Coords.
		//Triangular Prism (Lotion Bottle)
		//Triangle 1 Left Face
		0.35f, 1.0f, -0.2f,	-1.0f, 0.0f, 0.0f, 	1.0f, 0.0f, // Top Left

		0.45f, 0.2f, -0.25f,   	-1.0f, 0.0f, 0.0f,	1.0f, 1.0f, // Bottom Left Back

		0.45f, 0.2f, -0.15f,	-1.0f, 0.0f, 0.0f,	0.0f, 1.0f, // Bottom Left Front

		//Triangle 2 Right Face
		0.75f, 0.2f, -0.25f,	1.0f, 0.0f, 0.0f,	1.0f, 0.0f, // Bottom Right Back

		0.85f, 1.0f, -0.2f,	1.0f, 0.0f, 0.0f,	1.0f, 1.0f, // Top Right

		0.75f, 0.2f, -0.15f,	1.0f, 0.0f, 0.0f,	0.0f, 1.0f, // Bottom Right Front

		//Triangle 3 Back Face
		0.85f, 1.0f, -0.2f, 	0.0f, 0.0f, -1.0f,	1.0f, 0.0f, // Top Right

		0.35f, 1.0f, -0.2f,	0.0f, 0.0f, -1.0f,	1.0f, 1.0f, // Top Left

		0.75f, 0.2f, -0.25f,	0.0f, 0.0f, -1.0f,	0.0f, 1.0f, // Bottom Right Back

		//Triangle 4 Back Face
		0.35f, 1.0f, -0.2f,	0.0f, 0.0f, -1.0f,	1.0f, 0.0f, // Top Left

		0.45f, 0.2f, -0.25f,	0.0f, 0.0f, -1.0f,	1.0f, 1.0f, // Bottom Left Back

		0.75f, 0.2f, -0.25f,	0.0f, 0.0f, -1.0f, 	0.0f, 1.0f, // Bottom Right Back 

		//Triangle 5 Front Face
		0.85f, 1.0f, -0.2f, 	0.0f, 0.0f, 1.0f,	1.0f, 0.0f, // Top Right

		0.35f, 1.0f, -0.2f,	0.0f, 0.0f, 1.0f,	1.0f, 1.0f, // Top Left

		0.45f, 0.2f, -0.15f,	0.0f, 0.0f, 1.0f,	0.0f, 1.0f, // Bottom Left Front

		//Triangle 6 Front Face
		0.85f, 1.0f, -0.2f,	0.0f, 0.0f, 1.0f,	1.0f, 0.0f, // Top Right

		0.45f, 0.2f, -0.15f,	0.0f, 0.0f, 1.0f,	1.0f, 1.0f, // Bottom Left Front

		0.75f, 0.2f, -0.15f,	0.0f, 0.0f, 1.0f,	0.0f, 1.0f, // Bottom Right Front

		//Triangle 7 Bottom Face
		0.75f, 0.2f, -0.25f,	-1.0f, 0.0f, 0.0f,	1.0f, 0.0f, // Bottom Right Back

		0.45f, 0.2f, -0.25f,	-1.0f, 0.0f, 0.0f,	1.0f, 1.0f, // Bottom Left Back

		0.45f, 0.2f, -0.15f,	-1.0f, 0.0f, 0.0f,	0.0f, 1.0f, // Bottom Left Front

		//Triangle 8 Bottom Face
		0.75f, 0.2f, -0.25f,	 1.0f, 0.0f, 0.0f,	1.0f, 0.0f, // Bottom Right Back

		0.45f, 0.2f, -0.15f,	 1.0f, 0.0f, 0.0f,	1.0f, 1.0f, // Bottom Left Front


		0.75f, 0.2f, -0.15f,	 1.0f, 0.0f, 0.0f,	0.0f, 1.0f, // Bottom Right Front

		//Cylinder (Lotion Bottle Cap)
		//Bottom Circle
		//Triangle 1
		0.6f, 0.01f, -0.2f,	-1.0f, 0.0f, 0.0f,	1.0f, 0.0f, // Center Bottom

		0.45f, 0.01f, -0.25f,	-1.0f, 0.0f, 0.0f,	1.0f, 0.0f, // Bottom Left Back

		0.43f, 0.01f, -0.2f,	-1.0f, 0.0f, 0.0f,	0.0f, 0.0f, // Bottom Left

		//Triangle 2
		0.6f, 0.01f, -0.2f,	 1.0f, 0.0f, 0.0f,	1.0f, 0.0f, // Center Bottom

		0.6f, 0.01f, -0.26f,	 1.0f, 0.0f, 0.0f,	1.0f, 0.0f, // Bottom Center Back

		0.45f, 0.01f, -0.25f,	 1.0f, 0.0f, 0.0f,	0.0f, 0.0f, // Bottom Left Back

		//Triangle 3
		0.6f, 0.01f, -0.2f,	 0.0f,	0.0f, -1.0f,	1.0f, 0.0f, // Center Bottom

		0.75f, 0.01f, -0.25f,	 0.0f, 0.0f, -1.0f,	1.0f, 0.0f, // Bottom Right Back

		0.6f, 0.01f, -0.26f,	 0.0f, 0.0f, -1.0f,	0.0f, 0.0f, // Bottom Center Back

		//Triangle 4
		0.6f, 0.01f, -0.2f, 	 0.0f, 0.0f, 1.0f, 	1.0f, 0.0f, // Center Bottom

		0.77f, 0.01f, -0.2f, 	 0.0f, 0.0f, 1.0f,	1.0f, 0.0f, // Bottom Right

		0.75f, 0.01f, -0.25f,	 0.0f, 0.0f, 1.0f,	0.0f, 0.0f, // Bottom Right Back

		//Triangle 5
		0.6f, 0.01f, -0.2f, 	 0.0f, -1.0f, 0.0f,	1.0f, 0.0f, // Center Bottom

		0.75f, 0.01f, -0.15f,	 0.0f, -1.0f, 0.0f,	1.0f, 0.0f, // Bottom Right Front

		0.77f, 0.01f, -0.2f,	 0.0f, -1.0f, 0.0f,	0.0f, 0.0f, // Bottom Right

		//Triangle 6
		0.6f, 0.01f, -0.2f,	 0.0f, 1.0f, 0.0f,	1.0f, 0.0f, // Center Bottom

		0.6f, 0.01f, -0.14f,	 0.0f, 1.0f, 0.0f,	1.0f, 0.0f, // Bottom Center Front

		0.75f, 0.01f, -0.15f,	 0.0f, 1.0f, 0.0f,	0.0f, 0.0f, // Bottom Right Front

		//Triangle 7
		0.6f, 0.01f, -0.2f,	 1.0f, 0.0f, 0.0f,	1.0f, 0.0f, // Center Bottom

		0.45f, 0.01f, -0.15f,	 1.0f, 0.0f, 0.0f,	1.0f, 0.0f, // Bottom Left Front

		0.6f, 0.01f, -0.14f, 	 1.0f, 0.0f, 0.0f,	0.0f, 0.0f, // Bottom Center Front

		//Triangle 8
		0.6f, 0.01f, -0.2f,	-1.0f, 0.0f, 0.0f, 	1.0f, 0.0f, // Center Bottom

		0.43f, 0.01f, -0.2f,	-1.0f, 0.0f, 0.0f,	1.0f, 0.0f, // Bottom Left

		0.45f, 0.01f, -0.15f,	-1.0f, 0.0f, 0.0f,	0.0f, 0.0f, // Bottom Left Front

		//The circles connecting planes
		//Plane 1 Front
		0.6f, 0.01f, -0.14f,	 0.0f, 0.0f, -1.0f,	0.0f, 0.0f, // Bottom Center Front

		0.6f, 0.2f, -0.14f,	 0.0f, 0.0f, -1.0f,	0.0f, 0.0f, // Top Center Front

		0.45f, 0.01f, -0.15f,0.0f,0.0f, -1.0f,0.0f, 0.0f, // Bottom Left Front

		0.6f,0.2f,-0.14f,0.0f,0.0f, -1.0f,0.0f, 0.0f, // Top Center Front

		0.45f, 0.2f,-0.15f,0.0f,0.0f, -1.0f,0.0f, 0.0f, // Top Left Front

		0.45f, 0.01f, -0.15f,0.0f,0.0f, -1.0f,0.0f, 0.0f, // Bottom Left Front

		//Plane 2 Front
		0.75f, 0.01f, -0.15f,0.0f,0.0f,1.0f,0.0f, 0.0f, // Bottom Right Front

		0.75f, 0.2f,-0.15f,0.0f,0.0f,1.0f,0.0f, 0.0f, // Bottom Right Front 

		0.6f,0.01f, -0.14f,0.0f,0.0f,1.0f,0.0f, 0.0f, // Bottom Center Front

		0.75f, 0.2f,-0.15f,0.0f,0.0f,1.0f,0.0f, 0.0f, // Bottom Right Front

		0.6f,0.2f,-0.14f,0.0f,0.0f,1.0f,0.0f, 0.0f, // Bottom Center Front

		0.6f,0.01f, -0.14f,0.0f,0.0f,1.0f,0.0f, 0.0f, // Bottom Center Front

		//Plane 3 Left Front
		0.45f, 0.01f, -0.15f,-1.0f,0.0f,0.0f,0.0f, 0.0f, // Bottom Left Front

		0.45f, 0.2f,-0.15f,-1.0f,0.0f,0.0f,0.0f, 0.0f, // Bottom Left Front

		0.43f, 0.01f, -0.2f,-1.0f,0.0f,0.0f,0.0f, 0.0f, // Bottom Left

		0.45f, 0.2f,-0.15f,-1.0f,0.0f,0.0f,0.0f, 0.0f, // Bottom Left Front

		0.43f, 0.2f,-0.2f,-1.0f,0.0f,0.0f,0.0f, 0.0f, // Bottom Left

		0.43f, 0.01f, -0.2f,-1.0f,0.0f,0.0f,0.0f, 0.0f, // Bottom Left

		//Plane 4 Right Front
		0.77f, 0.01f, -0.2f,1.0f,0.0f,0.0f,0.0f, 0.0f, // Bottom Right

		0.77f, 0.2f,-0.2f,1.0f,0.0f,0.0f,0.0f, 0.0f, // Top Right

		0.75f, 0.01f, -0.15f,1.0f,0.0f,0.0f,0.0f, 0.0f, // Bottom Right FRont

		0.77f, 0.2f,-0.2f,1.0f,0.0f,0.0f,0.0f, 0.0f, // Top Right

		0.75f, 0.2f,-0.15f,1.0f,0.0f,0.0f,0.0f, 0.0f, // Top Right Front

		0.75f, 0.01f, -0.15f,1.0f,0.0f, 0.0f,0.0f, 0.0f, // Bottom Right Front

		//Plane 5 Back
		0.75f, 0.01f, -0.25f,0.0f, -1.0f, 0.0f,0.0f, 0.0f, // Bottom Right Back

		0.75f, 0.2f,-0.25f,0.0f, -1.0f, 0.0f,0.0f, 0.0f, // Top Right Back

		0.6f,0.01f, -0.26f,0.0f, -1.0f, 0.0f,0.0f, 0.0f, // Bottom Center Back

		0.75f, 0.2f,-0.25f,0.0f, -1.0f, 0.0f,0.0f, 0.0f, // Top Right Back

		0.6f,0.2f,-0.26f,0.0f, -1.0f, 0.0f,0.0f, 0.0f, // Top Center Back

		0.6f,0.01f, -0.26f,0.0f, -1.0f, 0.0f,0.0f, 0.0f, // Bottom Center Back

		//Plane 6 Back
		0.6f,0.01f, -0.26f,0.0f, 1.0f, 0.0f,0.0f, 0.0f, // Bottom Center Back 

		0.6f,0.2f,-0.26f,0.0f, 1.0f, 0.0f,0.0f, 0.0f, // Top Center Back

		0.45f, 0.01f, -0.25f,0.0f, 1.0f, 0.0f,0.0f, 0.0f, // Bottom Left Back

		0.6f,0.2f,-0.26f,0.0f, 1.0f, 0.0f,0.0f, 0.0f, // Top Center Back

		0.45f, 0.2f,-0.25f,0.0f, 1.0f, 0.0f,0.0f, 0.0f, // Top Left Back

		0.45f, 0.01f, -0.25f,0.0f, 1.0f, 0.0f,0.0f, 0.0f, // Bottom Left Back

		//Plane 7 Back Left
		0.45f, 0.01f, -0.25f, -1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Bottom Left Back

		0.45f, 0.2f,-0.25f, -1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Top Left Back

		0.43f, 0.01f, -0.2f,-1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Bottom Left

		0.45f, 0.2f,-0.25f, -1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Top Left Back

		0.43f, 0.2f,-0.2f,-1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Top Left 

		0.43f, 0.01f, -0.2f,-1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Bottom Left

		//Plane 8 Back Right
		0.77f, 0.01f, -0.2f,1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Bottom Right

		0.77f, 0.2f,-0.2f,1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Top Right 

		0.75f, 0.01f, -0.25f,1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Bottom Right Back

		0.77f, 0.2f,-0.2f,1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Top Right

		0.75f, 0.2f,-0.25f,1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Top Right Back

		0.75f, 0.01f, -0.25f,1.0f, 0.0f, 0.0f,0.0f, 0.0f, // Bottom Right Back 

		//Top Circle
		//Triangle 1
		0.6f,0.2f, -0.2f,0.0f, 0.0f, -1.0f,1.0f, 0.0f, // Center Top

		0.45f, 0.2f, -0.25f, 0.0f, 0.0f, -1.0f,1.0f, 1.0f, // Top Left Back

		0.43f, 0.2f, -0.2f,0.0f, 0.0f, -1.0f,0.0f, 1.0f, // Top Left 

		//Triangle 2
		0.6f, 0.2f, -0.2f,	0.0f, 0.0f, 1.0f, 	1.0f, 0.0f, // Center Top

		0.6f,0.2f, -0.26f, 0.0f, 0.0f, 1.0f,1.0f, 1.0f, // Top Center Back

		0.45f, 0.2f, -0.25f, 0.0f, 0.0f, 1.0f,0.0f, 1.0f,// Top Left Back

		//Triangle 3
		0.6f,0.2f, -0.2f,-1.0f, 0.0f, 0.0f,1.0f, 0.0f, // Center Top

		0.75f, 0.2f, -0.25f, -1.0f, 0.0f, 0.0f,1.0f, 1.0f, // Top Right Back

		0.6f,0.2f, -0.26f, -1.0f, 0.0f, 0.0f,0.0f, 1.0f, // Top Center Back

		//Triangle 4
		0.6f,0.2f, -0.2f,1.0f, 0.0f, 0.0f,1.0f, 0.0f, // Center Top 

		0.77f, 0.2f, -0.2f,1.0f, 0.0f, 0.0f,1.0f, 1.0f, // Top Right 

		0.75f, 0.2f, -0.25f, 1.0f, 0.0f, 0.0f,0.0f, 1.0f,// Top Right Back

		//Triangle 5
		0.6f,0.2f, -0.2f,0.0f, -1.0f, 0.0f,1.0f, 0.0f, // Center Top 

		0.75f, 0.2f, -0.15f, 0.0f, -1.0f, 0.0f,1.0f, 1.0f, // Top Right Front

		0.77f, 0.2f, -0.2f, 0.0f,-1.0f, 0.0f,0.0f, 1.0f, // Top Right 

		//Triangle 6
		0.6f,0.2f, -0.2f,0.0f, 1.0f, 0.0f,1.0f, 0.0f, // Center Top 

		0.6f,0.2f, -0.14f, 0.0f, 1.0f, 0.0f,1.0f, 1.0f, // Top Center Front

		0.75f, 0.2f, -0.15f, 0.0f, 1.0f, 0.0f,0.0f, 1.0f, // Top Right Front

		//Triangle 7
		0.6f,0.2f, -0.2f,0.0f, 0.0f, 1.0f,1.0f, 0.0f, // Center Top 

		0.45f, 0.2f, -0.15f, 0.0f, 0.0f, 1.0f,1.0f, 1.0f, // Top Left Front

		0.6f,0.2f, -0.14f, 0.0f, 0.0f, 1.0f,0.0f, 1.0f, // Top Center Front

		//Triangle 8
		0.6f,0.2f, -0.2f,0.0f, 0.0f, -1.0f,1.0f, 0.0f, // Center Top 

		0.43f, 0.2f, -0.2f,0.0f, 0.0f, -1.0f,1.0f, 1.0f, // Top Left 

		0.45f, 0.2f, -0.15f, 0.0f, 0.0f, -1.0f,0.0f, 1.0f,// Top Left Front

		//Plane
		//Triangle 1 Back Triangle
		-2.0f, 0.0f,2.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f, // Bottom Right Back GREEN

		-2.0f, 0.0f, -2.0f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f, // Bottom Left Front GREEN

		2.0f, 0.0f, -2.0f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f, // Bottom Right Front GREEN

		//Triangle 2 Front Triangle
		-2.0f, 0.0f,2.0f,0.0f, 0.0f, 1.0f, 0.0f, 1.0f, // Bottom Right Back GREEN

		2.0f, 0.0f, -2.0f,0.0f, 0.0f, 1.0f, 1.0f, 1.0f, // Bottom Right Front GREEN

		2.0f, 0.0f,2.0f,0.0f, 0.0f, 1.0f, 1.0f, 0.0f, // Bottom Right Front GREEN

		//Cube
		//Bottom Face
		-0.1f,0.01f,0.4f,-1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Front

		-0.1f,0.01f,0.1f,-1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Back

		0.2f,0.01f,0.1f,-1.0f, 0.0f, 0.0f, 0.0f, 1.0f, // Bottom Right Back

		0.2f,0.01f,0.4f,-1.0f, 0.0f, 0.0f, 0.0f, 1.0f, // Bottom Right Front

		-0.1f,0.01f,0.4f,-1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Front

		0.2f,0.01f,0.1f,-1.0f, 0.0f, 0.0f, 0.0f, 1.0f, // Bottom Right Back

		//Top Face
		-0.1f, 0.3f, 0.4f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left Front 

		-0.1f, 0.3f, 0.1f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left Back 

		0.2f, 0.3f, 0.1f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, // Top Right Back 

		0.2f, 0.3f, 0.4f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, // Top Right Front

		-0.1f, 0.3f, 0.4f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left Front 

		0.2f, 0.3f, 0.1f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, // Top Right Back 

		//Left Face
		-0.1f, 0.01f, 0.4f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Front

		-0.1f, 0.01f, 0.1f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Back

		-0.1f, 0.3f,0.1f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Left Back 

		-0.1f, 0.3f,0.4f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left Front 

		-0.1f, 0.01f, 0.4f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Front

		-0.1f, 0.3f,0.1f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Left Back 

		//Right Face
		0.2f, 0.01f, 0.4f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Front

		0.2f, 0.01f, 0.1f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Right Back

		0.2f, 0.3f,0.1f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Right Back 

		0.2f, 0.3f,0.4f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Front

		0.2f, 0.01f, 0.4f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Front

		0.2f, 0.3f,0.1f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Right Back 

		//Front Face
		-0.1f, 0.3f,0.4f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left Front 

		-0.1f, 0.01f, 0.4f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Front

		0.2f, 0.3f,0.4f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, // Top Right Front

		0.2f, 0.01f, 0.4f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, // Bottom Right Front

		0.2f, 0.3f,0.4f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, // Top Right Front

		-0.1f, 0.01f, 0.4f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Front

		//Back Face
		-0.1f, 0.3f,0.1f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left Back 

		-0.1f, 0.01f, 0.1f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Back

		0.2f, 0.3f,0.1f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, // Top Right Back 

		0.2f, 0.01f, 0.1f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, // Bottom Right Back

		0.2f, 0.3f,0.1f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, // Top Right Back 

		-0.1f, 0.01f, 0.1f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Back

		//Cylinder (Spray Bottle)
		//Large Cylinder
		//Bottom Circle
		0.05f, 0.01f, -0.35f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Front Center 

		0.05f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Center

		-0.05f, 0.01f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Front Left

		-0.05f, 0.01f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Front Left

		0.05f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Center

		-0.10f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left 

		-0.10f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left 

		0.05f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Center

		-0.05f, 0.01f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Back

		-0.05f, 0.01f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Back

		0.05f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Center

		0.05f, 0.01f, -0.65f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Back Center

		0.05f, 0.01f, -0.65f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Back Center

		0.05f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Center

		0.15f, 0.01f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Back

		0.15f, 0.01f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Back

		0.05f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Center

		0.20f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right

		0.20f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right

		0.05f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Center

		0.15f, 0.01f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Front

		0.15f, 0.01f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Front

		0.05f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Center

		0.05f, 0.01f, -0.35f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom FrontCenter 

		//Top Circle
		0.05f, 0.70f, -0.35f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Front Center

		0.05f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Center 

		-0.05f, 0.70f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Front Left

		-0.05f, 0.70f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Front Left

		0.05f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Center 

		-0.10f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left 

		-0.10f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Top Left

		0.05f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Center 

		-0.05f, 0.70f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left Back

		-0.05f, 0.70f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left Back

		0.05f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Center 

		0.05f, 0.70f, -0.65f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Back Center

		0.05f, 0.70f, -0.65f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Back Center

		0.05f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Center 

		0.15f, 0.70f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Back

		 0.15f, 0.70f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Back

		 0.05f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Center 

		 0.20f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right 

		 0.20f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right 

		 0.05f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Center 

		 0.15f, 0.70f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Front

		 0.15f, 0.70f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Front

		 0.05f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Center 

		 0.05f, 0.70f, -0.35f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Front Center

		 //Planes that connect the circles
		  0.05f, 0.01f, -0.35f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom FrontCenter 

		  0.05f, 0.70f, -0.35f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Front Center

		 -0.05f, 0.01f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Front Left

		  0.05f, 0.70f, -0.35f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Front Center

		 -0.05f, 0.01f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Front Left

		 -0.05f, 0.70f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Front Left

		 -0.05f, 0.01f, -0.40f,0.0f, 0.0f, -1.0f, 1.0f, 0.0f, // Bottom Front Left

		 -0.05f, 0.70f, -0.40f,0.0f, 0.0f, -1.0f, 1.0f, 0.0f, // Top Front Left

		 -0.10f, 0.01f, -0.50f,0.0f, 0.0f, -1.0f, 1.0f, 0.0f, // Bottom Left

		 -0.10f, 0.01f, -0.50f,0.0f, 0.0f, -1.0f, 1.0f, 0.0f, // Bottom Left

		 -0.05f, 0.70f, -0.40f,0.0f, 0.0f, -1.0f, 1.0f, 0.0f, // Top Front Left

		 -0.10f, 0.70f, -0.50f,0.0f, 0.0f, -1.0f, 1.0f, 0.0f, // Top Left 

		 -0.10f, 0.01f, -0.50f,1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left 

		 -0.10f, 0.70f, -0.50f,1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left 

		 -0.05f, 0.01f, -0.60f,1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Back

		 -0.05f, 0.01f, -0.60f,1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Back

		 -0.05f, 0.70f, -0.60f,1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left Back

		 -0.10f, 0.70f, -0.50f,1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left 

		 -0.05f, 0.01f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Back

		 -0.05f, 0.70f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left Back

		  0.05f, 0.01f, -0.65f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Back Center

		  0.05f, 0.01f, -0.65f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Back Center

		  0.05f, 0.70f, -0.65f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Back Center

		 -0.05f, 0.70f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left Back

		  0.05f, 0.01f, -0.65f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Back Center

		  0.05f, 0.70f, -0.65f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Back Center

		  0.15f, 0.01f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Back

		  0.15f, 0.01f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Back

		  0.15f, 0.70f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Back

		  0.05f, 0.70f, -0.65f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Back Center

		  0.15f, 0.01f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Back

		  0.15f, 0.70f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Back

		  0.20f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right

		  0.20f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right

		  0.20f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right 

		  0.15f, 0.70f, -0.60f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Back

		  0.20f, 0.01f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right

		  0.20f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right 

		  0.15f, 0.01f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Front

		  0.15f, 0.01f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Front

		  0.15f, 0.70f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Front

		  0.20f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right 

		  0.15f, 0.01f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Front

		  0.15f, 0.70f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Front

		  0.05f, 0.01f, -0.35f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Front Center 

		  0.05f, 0.01f, -0.35f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Front Center 

		  0.05f, 0.70f, -0.35f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Front Center

		  0.15f, 0.70f, -0.40f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Front

		  //Smaller Cylinder
		  //Bottom Circle
		   0.05f,0.70f, -0.425f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Front Center 

		   0.05f,0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Center

		   0.00f,0.70f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Front Left 

		   0.00f,0.70f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Front Left

		   0.05f,0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Center

		  -0.025f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left

		  -0.025f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left

		   0.05f,0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Center

		   0.00f,0.70f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom LeftBack 

		   0.00f,0.70f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom LeftBack 

		   0.05f,0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Center

		   0.05f,0.70f, -0.575f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Back Center 

		   0.05f,0.70f, -0.575f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Back Center 

		   0.05f,0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Center

		   0.10f,0.70f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Back 

		   0.10f,0.70f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Right Back 

		   0.05f,0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Center

		   0.125f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right

		   0.125f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Right

		   0.05f,0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Center

		   0.10f,0.70f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Front 

		   0.10f,0.70f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Right Front 

		   0.05f,0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Center

		   0.05f,0.70f, -0.425f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Front Center 

		   //Top Circle
			0.05f, 0.90f, -0.425f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Front Center

			0.05f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Center

			0.00f, 0.90f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Front Left

			0.00f, 0.90f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Front Left

			0.05f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Center

		   -0.025f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left

		   -0.025f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Left

			0.05f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Center

			0.00f, 0.90f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left Back

			0.00f, 0.90f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Left Back

			0.05f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Center

			0.05f, 0.90f, -0.575f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Back Center 

			0.05f, 0.90f, -0.575f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top BackCenter 

			0.05f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Center

			0.10f, 0.90f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Back

			0.10f, 0.90f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Right Back

			0.05f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Center

			0.125f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right

			0.125f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Right

			0.05f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Center

			0.10f, 0.90f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Front 

			0.10f, 0.90f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Right Front 

			0.05f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Center

			0.05f, 0.90f, -0.425f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Front Center 

			//Planes that connect the circles
			 0.05f, 0.70f, -0.425f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Front Center 

			 0.05f, 0.90f, -0.425f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Front Center 

			 0.00f, 0.70f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Front Left 

			 0.05f, 0.90f, -0.425f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Front Center 

			 0.00f, 0.70f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Front Left 

			 0.00f, 0.90f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Front Left

			 0.00f,0.70f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Front Left 

			 0.00f,0.90f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Front Left 

			-0.025f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left

			-0.025f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left

			 0.00f,0.90f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Front Left 

			-0.025f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Left

			-0.025f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left

			-0.025f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Left

			 0.00f,0.70f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Back 

			 0.00f,0.70f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Left Back 

			 0.00f,0.90f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Left Back

			-0.025f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Left

			 0.00f, 0.70f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Left Back 

			 0.00f, 0.90f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Left Back

			 0.05f, 0.70f, -0.575f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Back Center 

			 0.05f, 0.70f, -0.575f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Back Center 

			 0.05f, 0.90f, -0.575f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Back Center 

			 0.00f, 0.90f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Left Back

			 0.05f, 0.70f, -0.575f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Back Center 

			 0.05f, 0.90f, -0.575f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Back Center 

			 0.10f, 0.70f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Right Back 

			 0.10f, 0.70f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Right Back 

			 0.10f, 0.90f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Right Back

			 0.05f, 0.90f, -0.575f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Back Center 

			 0.10f,0.70f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Back 

			 0.10f,0.90f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Right Back 

			 0.125f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right

			 0.125f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Right

			 0.125f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Right

			 0.10f,0.90f, -0.55f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right Back 

			 0.125f, 0.70f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right

			 0.125f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Right

			 0.10f,0.70f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Right Front 

			 0.10f,0.70f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Right Front

			 0.10f,0.90f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Right Front

			 0.125f, 0.90f, -0.50f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Right

			 0.10f, 0.70f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Bottom Right Front 

			 0.10f, 0.90f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Right Front 

			 0.05f, 0.70f, -0.425f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Front Center 

			 0.05f, 0.70f, -0.425f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Bottom Front Center 

			 0.05f, 0.90f, -0.425f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, // Top Front Center 

			 0.10f, 0.90f, -0.45f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, // Top Right Front 

	};

	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerUV = 2;

	mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

	unsigned int VAO, VBO;

	glGenVertexArrays(1, &mesh.VAO);  
	glBindVertexArray(mesh.VAO);

	
	glGenBuffers(1, &mesh.VBO);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.VBO); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

	
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);
}
void UDestroyMesh(GLMesh& mesh)
{
	glDeleteVertexArrays(1, &mesh.VAO);
	glDeleteBuffers(1, &mesh.VBO);
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
	int width, height, channels;
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);

	if (image)
	{
		flipImageVertically(image, width, height, channels);
		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (channels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);

		else if (channels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

		else
		{
			cout << "Not implemented to handle image with " << channels << "channels" << endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texturereturn true;
	}

	// Error loading the image
	return false;
}

void UDestroyTexture(GLuint textureId)
{
	glGenTextures(1, &textureId);
}
// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{

	// Compilation and linkage error reporting
	int success = 0;
	char infoLog[512];

	// Create a Shader program object.
	programId = glCreateProgram();

	// Create the vertex and fragment shader objects
	GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
	GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

	// Retrieve the shader source
	glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
	glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

	// Compile the vertex shader
	glCompileShader(vertexShaderId); 
	// check for shader compile errors
	glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);

	if (!success)
	{
		glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

		return false;
	}

	glCompileShader(fragmentShaderId); // compile the fragment shader
	// check for shader compile errors
	glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);

	if (!success)
	{
		glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

		return false;
	}

	// Attached compiled shaders to the shader program
	glAttachShader(programId, vertexShaderId);
	glAttachShader(programId, fragmentShaderId);
	glLinkProgram(programId);

	// links the shader program
	// check for linking errors
	glGetProgramiv(programId, GL_LINK_STATUS, &success);

	if (!success)
	{
		glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

		return false;
	}

	glUseProgram(programId);
	// Uses the shader program
	return true;
}

void UDestroyShaderProgram(GLuint programId)
{
	glDeleteProgram(programId);
}


